#pragma once

int version();
